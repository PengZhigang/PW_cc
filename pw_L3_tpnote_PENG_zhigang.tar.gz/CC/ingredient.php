<?php
require('model_base.php');
class Ingrediant extends Model_Base{
	private $nom;
	private $quantite;
	const USER_TABLE = 'ingrediant';
	public function __construct($nom,$quantite){
		$this->nom=nom;
		$this->quantite=quantite;
		$this->USER_TABLE=table;
	}
	public function getNom(){
		return $this->nom;
	}
	public function getQuantite(){
		return $this->quantite;
	}
	public function getTable()
	{
		return $this->USER_TABLE;
	}
	public function setLogin($nom){
		$this->nom = $nom;
	}

	public function setQuantite($quantite)
	{
		$this->quantite = $quantite;
	}
	public function setTable($table){
		$this->USER_TABLE = $table;
	}
	public function exists()
	{
		$q = self::$_db->query("SELECT nom FROM " .self::USER_TABLE);
		while($data = $q->fetch(PDO::FETCH_ASSOC)) {
			foreach($data as $key) {
				if($this->nom==$key)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
	}

	public function create()
	{
		$q = self::$_db->prepare('INSERT INTO ' .self::USER_TABLE. '(nom, quantite) VALUES(:nom, :quantite)');
		$q->execute(array(
			'login' => $this->nom,
			'nom' => $this->quantite 
		));
	}

	public function changeQuantite($quantite)
	{
		$q = self::$_db->prepare('UPDATE ' .self::USER_TABLE. ' SET quantite = :quantite WHERE nom = :nom');
		$q->execute(array(
			'quantite' => $quantite,
			'nom' => $this->nom
		));
		User::quantite($quantite);
	}

	public function delete()
	{
		$q = self::$_db->prepare('DELETE FROM '.self::USER_TABLE. ' WHERE nom = :nom');
		$q->execute(array(
			'nom' => $this->nom
		));
	}
	public function affiche()
	{
		$q = self::$_db->query("SELECT * FROM " .self::USER_TABLE);
		if (!$q){
			die("valid resalt");
		}
		echo"<table>";
		echo"<tr><td>nom</td><td>quantité</td></tr>";
		while($row= mysql_fetch_row($q))
		{
			echo "<tr><td>$row[1]</td><td>$row[2]</td></tr>";
		}
		
		echo "</table>"; 
			
			
	}
}
?>
