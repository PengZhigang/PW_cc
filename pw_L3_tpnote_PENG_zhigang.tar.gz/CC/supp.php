<?php
	session_start();
	if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_SESSION['nom']) && isset($_SESSION['quantitie']))
	{
		$nom = htmlspecialchars($_SESSION['nom']);
		$quantite = htmlspecialchars($_SESSION['quantite']);
		//$table = htmlspecialchars($_SESSION['table']);
		$table="ingrediant";
		require('ingredient.php');
		require_once 'bdd.php';
		$db = new PDO(SQL_DSN, SQL_USERNAME, SQL_PASSWORD);
		$i = new Ingrediant($nom, $quantite,$table);

		$i->set_db($db);
		$i->delete();

		session_destroy();
		header('Location: ingredient_user.php');
		exit;
	}
	else
	{
		header('location: supp.php');
		exit;
	}
?>
