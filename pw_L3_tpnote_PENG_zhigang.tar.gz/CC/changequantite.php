
<?php
	session_start();
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(isset($_POST['nom'])&&isset($_POST['quantite1']) && isset($_POST['quantite2']))
		{
			//définit les mot de pass
			$quantite1 = htmlspecialchars($_POST['quantite1']);
			$quantite2 = htmlspecialchars($_POST['quantite2']);
			$nom = htmlspecialchars($_POST['nom']);
			if($quantite1 = $quantite2){
				header('Location: modifer.php');
				exit;
			}
			//import les fichiers locaux
			require('user.php');
			require_once 'bdd.php';
			//lianson entre le BDD
			$db = new PDO(SQL_DSN, SQL_USERNAME, SQL_PASSWORD);
			$table="ingrediant";
			$i = new Ingrediant($nom, $quantite1,$table);
			$i->set_db($db);
			$i->changePassword($mdp2);
			header('Location: index.php');
			exit;
		}
		else{
			header('Location: modifier.php');
			exit;
		}
	}
	else{
		header('Location: modifier.php');
		exit;
	}
?>
