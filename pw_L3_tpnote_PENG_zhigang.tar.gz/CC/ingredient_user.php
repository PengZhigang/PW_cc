
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Les ingredients</title>
</head>
<body>
	les ingredients:

<?php
require_once 'bdd.php';
$db = new PDO(SQL_DSN, SQL_USERNAME, SQL_PASSWORD);
$q = $db->query("SELECT * FROM ingrediant" );
if (!$q){
	die("valid resalt");
}
echo"<table>";
echo"<tr><td>nom</td><td>quantité</td></tr>";
while($row= $q->fetch())
{
	echo "<tr><td>$row[0]</td><td>$row[1]</td></tr>";
}
		
echo "</table>"; 
			

?>
<a href = "modifier.php"><br>Vous voulez les modifié?</br>

</body>
</html>
