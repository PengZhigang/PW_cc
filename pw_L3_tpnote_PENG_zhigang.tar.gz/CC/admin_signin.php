<form action="authenticate_admin.php" method="post">
	<br>login <input type="text"  name="login_admin"></br>
	<br>password <input type="password"  name="password_admin"></br>
	<br><input type="submit" value="login"></br>
	<br><a href="index.php">normal users?</a>
</form>
