<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Inscription</title>
</head>
<body>
	ajouter!
	<form action="add.php" method="post">
		<p>nom:<input type="text" name="nom" placeholder="nom"></p>
		<p>quantite:<input type="text" name="quantite" placeholder="quantite"></p>
		<p><input type="submit" name="Envoie" value="ajouter">
	</form>
	supprimer!
	<form action="supp.php" method="post">
		<p>nom:<input type="text" name="nom" placeholder="nom"></p>
		<p>quantite:<input type="text" name="quantite" placeholder="quantite"></p>
		<p><input type="submit" name="Envoie" value="supprimer">
	</form>
	changer!!
		<form action="changequantite.php" method="post">
			<p><input type="text" name="nom" placeholder="nom"></p>
			<p><input type="text" name="quantite1" placeholder="quantite"></p>
			<p><input type="text" name="quantite2" placeholder="quantite"></p>
			<p><input type="submit" name="Envoie" value="Changer de quantite"></p>
		</form>
		<a href="ingredient_user.php">Bienvenu</a>

</body>
</html>
