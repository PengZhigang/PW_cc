
<form action="authenticate.php" method="post">
	<br>login <input type="text"  name="login"></br>
	<br>password <input type="password"  name="password"></br>
	<br><input type="submit" value="login"></br>
	<br><a href="admin_signin.php">admin?</a>
</form>
