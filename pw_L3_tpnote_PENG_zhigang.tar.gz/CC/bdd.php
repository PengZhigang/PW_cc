<?php
define('SQL_DSN', 'mysql:host=osr-mysql.unistra.fr;dbname=zpeng');
define('SQL_USERNAME', 'zpeng');
define('SQL_PASSWORD', 'pzg885646446');
?>
