<?php

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(isset($_POST['nom']) && isset($_POST['quantite'])){
			$nom = htmlspecialchars($_POST['nom']);
			$quantite = htmlspecialchars($_POST['quantite']);
		require('ingredient.php');
		require_once 'bdd.php';
		$table= "ingrediant"
		$db = new PDO(SQL_DSN, SQL_USERNAME, SQL_PASSWORD);
		$i = new Ingrediant($nom, $quantite,$table);
		$i->set_db($db);
		$i->create();
		header('Location: ingredient_user.php');
		exit;
		}
		else
		header('Location: add.php');
		exit;
	}
	else
		header('Location: add.php');
	exit;
?>
