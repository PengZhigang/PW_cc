<?php
session_start();
include "bdd.php";
try {
	$db= new PDO(SQL_DSN, SQL_USERNAME, SQL_PASSWORD);
	//echo "connection with mysql.<br>";
} catch (Exception $e) {
	echo "ne peut pas connecter avec le base de donnees";
	exit;
}
if($_SERVER['REQUEST_METHOD']!="POST")
{ 
	//or use: header("Location: localhost/tp2/signin.php");
	echo "REQUEST_METHOD MUST BE POST!!"; 
	exit;
}
if ( isset($_POST['login_admin']) && isset($_POST['password_admin']) )
{
    $login = htmlentities($_POST['login_admin']);
    $password = htmlentities($_POST['password_admin']);
}

if($login == "" || $password == "")  
{  
	echo "Saisir le mot de passe SVP！";  
	exit;
} 

function getLoginByUsers($l) {
 	global $db;
 	 $statement = $db->prepare('SELECT * FROM admin WHERE login = :l');
	 $statement->bindValue(':l', $l, PDO::PARAM_STR);
	 $statement->execute();
	 return $statement->fetchAll();
}

if(!getLoginByUsers($_POST["login_admin"])) 
{
	$_SESSION["message"]="ne peux pas connecter avec ce login " . $login;
	echo "Login ou mot de passe incorrect！";  
	exit;
}


function verifymdp($lg,$pwd,$db){
	$res = $db->query("SELECT password FROM admin WHERE login='" . $lg . "'");
	while($data = $res->fetch(PDO::FETCH_ASSOC)) {
	foreach($data as $key) {
		if($pwd==$key)
 			return true;
 		else
 			return false;
		}
	}
}
if(!verifymdp($login,$password,$db))
{ 
	$_SESSION["message"]="mot de pass incorrect " . $login;
	echo "Login ou mot de pass incorrect！";  
	exit;
}  
$_SESSION['user']=$login;
echo $_SESSION['user'];
header("Location: ingredient_admin.php");
?>
